@echo off
REM Quick setup script for Windows

echo ================================
echo AI Resume Builder - Setup Script
echo ================================
echo.

REM Check Python installation
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH
    echo Please install Python 3.8+ from https://www.python.org/
    pause
    exit /b 1
)

echo [1/5] Python found
echo.

REM Create virtual environment
echo [2/5] Creating virtual environment...
python -m venv venv
if errorlevel 1 (
    echo ERROR: Failed to create virtual environment
    pause
    exit /b 1
)

echo Virtual environment created successfully
echo.

REM Activate virtual environment and install dependencies
echo [3/5] Installing dependencies...
call venv\Scripts\activate.bat
pip install -r requirements.txt
if errorlevel 1 (
    echo ERROR: Failed to install dependencies
    pause
    exit /b 1
)

echo Dependencies installed successfully
echo.

REM Check Ollama installation
echo [4/5] Checking Ollama installation...
ollama --version >nul 2>&1
if errorlevel 1 (
    echo WARNING: Ollama is not installed
    echo Please install Ollama from https://ollama.ai
    echo After installation, run: ollama pull llama3:instruct
) else (
    echo Ollama found
    echo Pulling llama3:instruct model...
    ollama pull llama3:instruct
)

echo.
echo [5/5] Setup complete!
echo.
echo ================================
echo Next Steps:
echo ================================
echo 1. Ensure Ollama is running: ollama serve
echo 2. Activate the environment: venv\Scripts\activate
echo 3. Run the app: python app.py
echo 4. Open browser: http://localhost:5000
echo ================================
echo.
pause
