"""
DOCX Resume Parser
Extracts text and structure from DOCX resumes
"""
import logging
from typing import Optional
import docx

logger = logging.getLogger(__name__)


class DOCXParser:
    """Parse DOCX resume files"""
    
    @staticmethod
    def parse(file_path: str) -> Optional[str]:
        """
        Extract text from DOCX resume
        
        Args:
            file_path: Path to DOCX file
            
        Returns:
            Extracted text or None if failed
        """
        try:
            logger.info(f"Parsing DOCX: {file_path}")
            
            doc = docx.Document(file_path)
            
            # Extract text from all paragraphs
            text = ''
            for paragraph in doc.paragraphs:
                text += paragraph.text + '\n'
            
            # Extract text from tables
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        text += cell.text + '\n'
            
            logger.info(f"Successfully extracted {len(text)} characters from DOCX")
            return text.strip()
            
        except Exception as e:
            logger.error(f"Error parsing DOCX: {str(e)}")
            return None
    
    @staticmethod
    def extract_structured_data(text: str) -> dict:
        """
        Extract structured information from resume text
        
        Args:
            text: Raw text from resume
            
        Returns:
            Dictionary with structured data
        """
        lines = text.split('\n')
        
        return {
            'raw_text': text,
            'line_count': len(lines),
            'sections_detected': DOCXParser._detect_sections(text)
        }
    
    @staticmethod
    def _detect_sections(text: str) -> list:
        """Detect common resume sections"""
        sections = []
        common_headers = [
            'summary', 'objective', 'profile',
            'experience', 'work history', 'employment',
            'education', 'academic',
            'skills', 'technical skills', 'competencies',
            'projects', 'portfolio',
            'certifications', 'certificates', 'licenses',
            'achievements', 'awards', 'honors'
        ]
        
        text_lower = text.lower()
        
        for header in common_headers:
            if header in text_lower:
                sections.append(header)
        
        return list(set(sections))  # Remove duplicates
