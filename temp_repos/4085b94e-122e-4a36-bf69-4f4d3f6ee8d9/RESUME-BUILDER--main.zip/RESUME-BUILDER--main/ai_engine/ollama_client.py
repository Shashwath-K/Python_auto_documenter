"""
Ollama client for interacting with local LLM
"""
import json
import logging
from typing import Dict, Any, Optional
import ollama

logger = logging.getLogger(__name__)


class OllamaClient:
    """Client for interacting with Ollama LLM"""
    
    def __init__(self, model: str = 'llama3:instruct', host: str = 'http://localhost:11434'):
        """
        Initialize Ollama client
        
        Args:
            model: Name of the Ollama model to use
            host: Ollama server host URL
        """
        self.model = model
        self.host = host
        logger.info(f"Initialized Ollama client with model: {model}")
    
    def generate_resume(self, system_prompt: str, user_prompt: str) -> Optional[Dict[str, Any]]:
        """
        Generate resume using Ollama
        
        Args:
            system_prompt: System instructions for the LLM
            user_prompt: User-specific context and requirements
            
        Returns:
            Parsed JSON response containing resume data, or None if failed
        """
        try:
            logger.info("Sending request to Ollama...")
            
            # Construct the full prompt
            full_prompt = f"{system_prompt}\n\n{user_prompt}\n\nReturn only valid JSON, no additional text."
            
            # Call Ollama
            response = ollama.generate(
                model=self.model,
                prompt=full_prompt,
                options={
                    'temperature': 0.7,
                    'top_p': 0.9,
                }
            )
            
            # Extract response text
            response_text = response.get('response', '').strip()
            logger.debug(f"Raw response: {response_text[:200]}...")
            
            # Parse JSON from response
            resume_data = self._extract_json(response_text)
            
            if resume_data:
                logger.info("Successfully generated resume data")
                return resume_data
            else:
                logger.error("Failed to extract valid JSON from response")
                return None
                
        except Exception as e:
            logger.error(f"Error generating resume: {str(e)}")
            return None
    
    def _extract_json(self, text: str) -> Optional[Dict[str, Any]]:
        """
        Extract and parse JSON from LLM response
        
        Args:
            text: Response text that may contain JSON
            
        Returns:
            Parsed JSON dictionary or None
        """
        # Try to parse the entire response as JSON first
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
        
        # Try to find JSON within code blocks
        if '```json' in text:
            start = text.find('```json') + 7
            end = text.find('```', start)
            if end != -1:
                json_text = text[start:end].strip()
                try:
                    return json.loads(json_text)
                except json.JSONDecodeError:
                    pass
        
        # Try to find JSON within curly braces
        start = text.find('{')
        end = text.rfind('}')
        if start != -1 and end != -1 and end > start:
            json_text = text[start:end+1]
            try:
                return json.loads(json_text)
            except json.JSONDecodeError:
                pass
        
        return None
    
    def check_connection(self) -> bool:
        """
        Check if Ollama is accessible
        
        Returns:
            True if connected, False otherwise
        """
        try:
            models = ollama.list()
            logger.info(f"Connected to Ollama. Available models: {len(models.get('models', []))}")
            return True
        except Exception as e:
            logger.error(f"Cannot connect to Ollama: {str(e)}")
            return False
