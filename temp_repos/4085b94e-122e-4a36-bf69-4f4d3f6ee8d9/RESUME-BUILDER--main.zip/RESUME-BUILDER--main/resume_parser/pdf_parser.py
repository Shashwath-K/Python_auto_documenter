"""
PDF Resume Parser
Extracts text and structure from PDF resumes
"""
import logging
from typing import Optional
import PyPDF2

logger = logging.getLogger(__name__)


class PDFParser:
    """Parse PDF resume files"""
    
    @staticmethod
    def parse(file_path: str) -> Optional[str]:
        """
        Extract text from PDF resume
        
        Args:
            file_path: Path to PDF file
            
        Returns:
            Extracted text or None if failed
        """
        try:
            logger.info(f"Parsing PDF: {file_path}")
            
            with open(file_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                
                # Extract text from all pages
                text = ''
                for page_num in range(len(pdf_reader.pages)):
                    page = pdf_reader.pages[page_num]
                    text += page.extract_text() + '\n'
                
                logger.info(f"Successfully extracted {len(text)} characters from PDF")
                return text.strip()
                
        except Exception as e:
            logger.error(f"Error parsing PDF: {str(e)}")
            return None
    
    @staticmethod
    def extract_structured_data(text: str) -> dict:
        """
        Extract structured information from resume text
        
        Args:
            text: Raw text from resume
            
        Returns:
            Dictionary with structured data
        """
        # This is a simplified implementation
        # Can be enhanced with more sophisticated NLP
        
        lines = text.split('\n')
        
        return {
            'raw_text': text,
            'line_count': len(lines),
            'sections_detected': PDFParser._detect_sections(text)
        }
    
    @staticmethod
    def _detect_sections(text: str) -> list:
        """Detect common resume sections"""
        sections = []
        common_headers = [
            'summary', 'objective', 'profile',
            'experience', 'work history', 'employment',
            'education', 'academic',
            'skills', 'technical skills', 'competencies',
            'projects', 'portfolio',
            'certifications', 'certificates', 'licenses',
            'achievements', 'awards', 'honors'
        ]
        
        text_lower = text.lower()
        
        for header in common_headers:
            if header in text_lower:
                sections.append(header)
        
        return list(set(sections))  # Remove duplicates
