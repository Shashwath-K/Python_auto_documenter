"""
PDF Generator
Converts HTML resume to ATS-compliant PDF
"""
import logging
from typing import Optional
from weasyprint import HTML, CSS
import os

logger = logging.getLogger(__name__)


class PDFGenerator:
    """Generate PDF resumes from HTML"""
    
    # ATS-compliant CSS
    ATS_CSS = """
        @page {
            size: Letter;
            margin: 0.5in 0.75in;
        }
        
        body {
            font-family: "Times New Roman", Times, serif;
            font-size: 11.5pt;
            line-height: 1.5;
            color: #000;
            margin: 0;
            padding: 0;
        }
        
        h1 {
            font-size: 18pt;
            margin: 0 0 5px 0;
            text-align: center;
            font-weight: bold;
        }
        
        h2 {
            font-size: 14pt;
            margin-top: 15px;
            margin-bottom: 8px;
            border-bottom: 1.5px solid #000;
            padding-bottom: 3px;
            font-weight: bold;
        }
        
        h3 {
            font-size: 12pt;
            margin: 10px 0 5px 0;
            font-weight: bold;
        }
        
        p {
            margin: 5px 0;
        }
        
        ul {
            margin: 5px 0 10px 20px;
            padding: 0;
        }
        
        li {
            margin: 3px 0;
        }
        
        .header {
            text-align: center;
            margin-bottom: 15px;
        }
        
        .contact-info {
            text-align: center;
            font-size: 10.5pt;
            margin-bottom: 10px;
        }
        
        .section {
            margin-bottom: 12px;
            page-break-inside: avoid;
        }
        
        .experience-item, .project-item, .education-item {
            margin-bottom: 12px;
            page-break-inside: avoid;
        }
        
        .item-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 3px;
        }
        
        .skills-list {
            margin-left: 0;
            padding-left: 0;
            list-style-type: none;
        }
        
        .skills-category {
            margin-bottom: 5px;
        }
        
        strong {
            font-weight: bold;
        }
        
        .page-break {
            page-break-before: always;
        }
        
        /* Ensure no graphics or unnecessary styling */
        img, svg {
            display: none;
        }
    """
    
    @staticmethod
    def generate(html_content: str, output_path: str) -> bool:
        """
        Generate PDF from HTML content
        
        Args:
            html_content: HTML string of the resume
            output_path: Path where PDF should be saved
            
        Returns:
            True if successful, False otherwise
        """
        try:
            logger.info(f"Generating PDF: {output_path}")
            
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            # Convert HTML to PDF
            HTML(string=html_content).write_pdf(
                output_path,
                stylesheets=[CSS(string=PDFGenerator.ATS_CSS)]
            )
            
            logger.info(f"Successfully generated PDF: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error generating PDF: {str(e)}")
            return False
    
    @staticmethod
    def validate_two_pages(pdf_path: str) -> dict:
        """
        Validate that PDF is approximately 2 pages
        
        Args:
            pdf_path: Path to PDF file
            
        Returns:
            Dictionary with validation results
        """
        try:
            import PyPDF2
            
            with open(pdf_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                page_count = len(pdf_reader.pages)
            
            return {
                'valid': page_count <= 2,
                'page_count': page_count,
                'message': f"PDF has {page_count} page(s)"
            }
            
        except Exception as e:
            logger.error(f"Error validating PDF: {str(e)}")
            return {
                'valid': False,
                'page_count': 0,
                'message': f"Error: {str(e)}"
            }
