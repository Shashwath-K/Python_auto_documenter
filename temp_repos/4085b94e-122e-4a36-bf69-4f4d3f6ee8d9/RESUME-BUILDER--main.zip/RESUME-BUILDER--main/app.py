"""
Main Flask application for AI-powered Resume Builder
"""
import os
import logging
from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for
from werkzeug.utils import secure_filename
from config import Config
from ai_engine.ollama_client import OllamaClient
from ai_engine.prompt_builder import PromptBuilder
from ai_engine.jd_analyzer import JDAnalyzer
from ai_engine.github_scraper import GitHubScraper
from ai_engine.linkedin_parser import LinkedInParser
from resume_parser.pdf_parser import PDFParser
from resume_parser.docx_parser import DOCXParser
from utils.pdf_generator import PDFGenerator
import uuid
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.config.from_object(Config)
Config.init_app(app)

# Initialize AI components
ollama_client = OllamaClient(
    model=app.config['OLLAMA_MODEL'],
    host=app.config['OLLAMA_HOST']
)

# Ensure required directories exist
os.makedirs('uploads', exist_ok=True)
os.makedirs('output', exist_ok=True)


@app.route('/')
def index():
    """Main form page"""
    return render_template('form.html')


@app.route('/generate', methods=['POST'])
def generate_resume():
    """Generate resume based on form input"""
    try:
        mode = request.form.get('mode', 'mode1')
        logger.info(f"Generating resume in {mode}")
        
        if mode == 'mode1':
            resume_data = generate_mode1()
        else:
            resume_data = generate_mode2()
        
        if resume_data is None:
            return render_template('error.html', 
                error='Failed to generate resume. Please check your inputs and try again.')
        
        # Generate unique filename
        filename = f"resume_{uuid.uuid4().hex[:8]}.pdf"
        
        # Render HTML template
        html_content = render_template('preview.html', 
                                      resume_data=resume_data,
                                      filename=filename)
        
        # Generate PDF
        pdf_path = os.path.join('output', filename)
        success = PDFGenerator.generate(html_content, pdf_path)
        
        if not success:
            return render_template('error.html',
                error='Failed to generate PDF. Please try again.')
        
        # Validate page count
        validation = PDFGenerator.validate_two_pages(pdf_path)
        logger.info(f"PDF validation: {validation['message']}")
        
        # Render preview
        return render_template('preview.html', 
                             resume_data=resume_data,
                             filename=filename)
        
    except Exception as e:
        logger.error(f"Error in generate_resume: {str(e)}", exc_info=True)
        return render_template('error.html', 
            error=f'An error occurred: {str(e)}')


def generate_mode1():
    """Generate resume from job description (Mode 1)"""
    try:
        # Extract form data
        full_name = request.form.get('full_name', '').strip()
        job_description = request.form.get('job_description', '').strip()
        experience_level = request.form.get('experience_level', '').strip()
        skills = request.form.get('skills', '').strip()
        education = request.form.get('education', '').strip()
        
        # Validate required fields
        if not all([full_name, job_description, experience_level]):
            logger.error("Missing required fields for Mode 1")
            return None
        
        # Parse skills
        skills_list = [s.strip() for s in skills.split(',')] if skills else []
        
        # Analyze JD
        jd_analysis = JDAnalyzer.analyze(job_description)
        logger.info(f"JD Analysis - Role: {jd_analysis['role']}, Keywords: {len(jd_analysis['keywords'])}")
        
        # Build prompt
        user_prompt = PromptBuilder.build_mode1_prompt(
            full_name=full_name,
            job_description=job_description,
            experience_level=experience_level,
            skills=skills_list,
            education=education
        )
        
        # Generate resume with Ollama
        system_prompt = PromptBuilder.get_system_prompt()
        resume_data = ollama_client.generate_resume(system_prompt, user_prompt)
        
        if resume_data:
            logger.info("Successfully generated resume data from Mode 1")
            return resume_data
        else:
            logger.error("Failed to generate resume data from Ollama")
            return None
            
    except Exception as e:
        logger.error(f"Error in generate_mode1: {str(e)}", exc_info=True)
        return None


def generate_mode2():
    """Generate resume from profile analysis (Mode 2)"""
    try:
        # Extract form data
        target_jd = request.form.get('target_jd', '').strip()
        github_url = request.form.get('github_url', '').strip()
        linkedin_url = request.form.get('linkedin_url', '').strip()
        
        # Handle file upload
        resume_text = None
        if 'resume_file' in request.files:
            file = request.files['resume_file']
            if file and file.filename:
                filename = secure_filename(file.filename)
                filepath = os.path.join('uploads', filename)
                file.save(filepath)
                
                # Parse resume
                if filename.lower().endswith('.pdf'):
                    resume_text = PDFParser.parse(filepath)
                elif filename.lower().endswith('.docx'):
                    resume_text = DOCXParser.parse(filepath)
                
                logger.info(f"Parsed resume: {len(resume_text) if resume_text else 0} characters")
        
        # Analyze GitHub
        github_data = None
        if github_url:
            github_scraper = GitHubScraper(app.config.get('GITHUB_TOKEN'))
            username = GitHubScraper.extract_username(github_url)
            if username:
                github_data = github_scraper.analyze_profile(username)
                logger.info(f"GitHub analysis: {github_data.get('repo_count', 0)} repos")
        
        # LinkedIn data (placeholder - manual entry)
        linkedin_data = None
        if linkedin_url:
            # For now, just note that LinkedIn was provided
            logger.info("LinkedIn URL provided (manual parsing not implemented)")
        
        # Validate that at least one source is provided
        if not any([resume_text, github_data, linkedin_data]):
            logger.error("No data sources provided for Mode 2")
            return None
        
        # Build prompt
        user_prompt = PromptBuilder.build_mode2_prompt(
            job_description=target_jd,
            resume_text=resume_text,
            github_data=github_data,
            linkedin_data=linkedin_data
        )
        
        # Generate resume with Ollama
        system_prompt = PromptBuilder.get_system_prompt()
        resume_data = ollama_client.generate_resume(system_prompt, user_prompt)
        
        if resume_data:
            logger.info("Successfully generated resume data from Mode 2")
            return resume_data
        else:
            logger.error("Failed to generate resume data from Ollama")
            return None
            
    except Exception as e:
        logger.error(f"Error in generate_mode2: {str(e)}", exc_info=True)
        return None


@app.route('/download/<filename>')
def download_resume(filename):
    """Download generated PDF resume"""
    try:
        filepath = os.path.join('output', secure_filename(filename))
        if os.path.exists(filepath):
            return send_file(filepath, as_attachment=True, download_name=filename)
        else:
            return "File not found", 404
    except Exception as e:
        logger.error(f"Error downloading file: {str(e)}")
        return "Error downloading file", 500


@app.route('/health')
def health_check():
    """Health check endpoint"""
    ollama_status = ollama_client.check_connection()
    return jsonify({
        'status': 'healthy' if ollama_status else 'degraded',
        'ollama': 'connected' if ollama_status else 'disconnected',
        'timestamp': datetime.now().isoformat()
    })


if __name__ == '__main__':
    # Check Ollama connection on startup
    if not ollama_client.check_connection():
        logger.warning("WARNING: Cannot connect to Ollama. Please ensure Ollama is running.")
        logger.warning(f"Expected Ollama at: {app.config['OLLAMA_HOST']}")
        logger.warning("Install Ollama from: https://ollama.ai")
    else:
        logger.info(f"Successfully connected to Ollama at {app.config['OLLAMA_HOST']}")
    
    # Run Flask app
    app.run(debug=app.config['DEBUG'], host='0.0.0.0', port=5000)
