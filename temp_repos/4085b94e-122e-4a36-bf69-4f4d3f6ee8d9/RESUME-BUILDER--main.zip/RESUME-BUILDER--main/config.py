"""
Configuration settings for the AI-powered ATS Resume Builder
"""
import os

class Config:
    """Application configuration"""
    
    # Flask settings
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
    
    # Ollama settings
    OLLAMA_HOST = os.environ.get('OLLAMA_HOST') or 'http://localhost:11434'
    OLLAMA_MODEL = os.environ.get('OLLAMA_MODEL') or 'llama3:instruct'
    
    # Upload settings
    UPLOAD_FOLDER = 'uploads'
    ALLOWED_EXTENSIONS = {'pdf', 'docx'}
    
    # PDF generation settings
    PDF_PAGE_SIZE = 'Letter'
    PDF_MARGIN_TOP = '0.5in'
    PDF_MARGIN_BOTTOM = '0.5in'
    PDF_MARGIN_LEFT = '0.75in'
    PDF_MARGIN_RIGHT = '0.75in'
    
    # GitHub API settings
    GITHUB_API_BASE = 'https://api.github.com'
    GITHUB_TOKEN = os.environ.get('GITHUB_TOKEN')  # Optional, for higher rate limits
    
    # Application settings
    DEBUG = os.environ.get('FLASK_DEBUG') or True
    
    @staticmethod
    def init_app(app):
        """Initialize application with config"""
        # Create upload folder if it doesn't exist
        os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
