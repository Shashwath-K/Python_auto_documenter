"""AI Engine package for resume generation"""
