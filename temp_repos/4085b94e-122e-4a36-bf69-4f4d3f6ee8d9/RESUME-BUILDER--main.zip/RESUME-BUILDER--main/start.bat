@echo off
REM Quick start script for the application

echo Starting AI Resume Builder...
echo.

REM Activate virtual environment
call venv\Scripts\activate.bat

REM Check if Ollama is running
curl -s http://localhost:11434 >nul 2>&1
if errorlevel 1 (
    echo WARNING: Ollama does not appear to be running
    echo Please start Ollama in another terminal: ollama serve
    echo.
    pause
)

REM Start the Flask application
python app.py
