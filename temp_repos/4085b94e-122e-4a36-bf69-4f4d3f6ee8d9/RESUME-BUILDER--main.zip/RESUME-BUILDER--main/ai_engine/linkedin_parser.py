"""
LinkedIn Parser
Handles LinkedIn data extraction (manual entry or file upload)
Note: Direct LinkedIn scraping is challenging due to anti-scraping measures.
This module supports manual data entry or parsing of exported LinkedIn data.
"""
import logging
from typing import Dict, Optional, List

logger = logging.getLogger(__name__)


class LinkedInParser:
    """Parser for LinkedIn profile data"""
    
    @staticmethod
    def parse_manual_entry(data: Dict) -> Dict:
        """
        Parse manually entered LinkedIn data
        
        Args:
            data: Dictionary containing manually entered profile information
            
        Returns:
            Structured LinkedIn data
        """
        return {
            'name': data.get('name', ''),
            'headline': data.get('headline', ''),
            'experience': LinkedInParser._parse_experience(data.get('experience', [])),
            'education': LinkedInParser._parse_education(data.get('education', [])),
            'skills': data.get('skills', []),
            'certifications': data.get('certifications', []),
            'experience_summary': LinkedInParser._create_experience_summary(
                data.get('experience', [])
            )
        }
    
    @staticmethod
    def _parse_experience(experience_list: List[Dict]) -> List[Dict]:
        """Parse experience entries"""
        parsed = []
        
        for exp in experience_list:
            parsed.append({
                'title': exp.get('title', ''),
                'company': exp.get('company', ''),
                'location': exp.get('location', ''),
                'start_date': exp.get('start_date', ''),
                'end_date': exp.get('end_date', 'Present'),
                'description': exp.get('description', ''),
                'duration': LinkedInParser._calculate_duration(
                    exp.get('start_date', ''),
                    exp.get('end_date', '')
                )
            })
        
        return parsed
    
    @staticmethod
    def _parse_education(education_list: List[Dict]) -> List[Dict]:
        """Parse education entries"""
        parsed = []
        
        for edu in education_list:
            parsed.append({
                'institution': edu.get('institution', ''),
                'degree': edu.get('degree', ''),
                'field': edu.get('field', ''),
                'start_date': edu.get('start_date', ''),
                'end_date': edu.get('end_date', ''),
                'grade': edu.get('grade', '')
            })
        
        return parsed
    
    @staticmethod
    def _calculate_duration(start_date: str, end_date: str) -> str:
        """Calculate duration between dates"""
        # Simple implementation - can be enhanced
        if not start_date:
            return 'N/A'
        
        if not end_date or end_date.lower() == 'present':
            return f"Since {start_date}"
        
        return f"{start_date} - {end_date}"
    
    @staticmethod
    def _create_experience_summary(experience_list: List[Dict]) -> str:
        """Create a summary of work experience"""
        if not experience_list:
            return "No experience data provided"
        
        total_years = len(experience_list)  # Simplified calculation
        companies = [exp.get('company', 'Unknown') for exp in experience_list]
        
        summary = f"{total_years} position(s) at {', '.join(companies[:3])}"
        if len(companies) > 3:
            summary += f" and {len(companies) - 3} more"
        
        return summary
    
    @staticmethod
    def parse_from_text(text: str) -> Optional[Dict]:
        """
        Attempt to parse LinkedIn profile from plain text
        (e.g., from copy-pasted profile or exported data)
        
        Args:
            text: Plain text containing LinkedIn profile information
            
        Returns:
            Structured data or None
        """
        # This is a placeholder for text parsing logic
        # Can be enhanced to parse structured text exports
        logger.warning("Text parsing not fully implemented. Use manual entry for best results.")
        
        return {
            'name': '',
            'headline': '',
            'experience': [],
            'education': [],
            'skills': [],
            'certifications': [],
            'experience_summary': 'Parsed from text input'
        }
