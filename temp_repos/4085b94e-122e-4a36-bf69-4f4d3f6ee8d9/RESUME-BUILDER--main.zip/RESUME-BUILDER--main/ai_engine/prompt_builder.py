"""
Prompt builder for generating context-specific prompts for Ollama
"""
from typing import Dict, Any, List, Optional


class PromptBuilder:
    """Builds prompts for resume generation"""
    
    SYSTEM_PROMPT = """You are an expert ATS Resume Writer and Technical Recruiter.

Your task is to generate a 2-page ATS-optimized resume.

STRICT RULES:
- No fake experience
- No fake companies
- No fake certifications
- No decorative symbols
- No emojis
- No icons
- No tables
- No columns
- No graphics
- Professional tone
- Quantify achievements where possible
- Follow exact section order

Resume Structure:
1. Header (Name + Contact)
2. Professional Summary
3. Education
4. Technical Skills
5. Work Experience
6. Projects
7. Certifications & Achievements

Ensure:
- Bullet points begin with strong action verbs
- ATS keywords from JD are naturally included
- No keyword stuffing
- Clear and concise formatting
- Output strictly in structured JSON

Return JSON only with this exact structure:
{
  "header": {
    "name": "",
    "title": "",
    "email": "",
    "phone": "",
    "linkedin": "",
    "github": ""
  },
  "summary": "",
  "education": [
    {
      "degree": "",
      "major": "",
      "institution": "",
      "location": "",
      "graduation_date": "",
      "gpa": ""
    }
  ],
  "skills": {
    "technical": [],
    "tools": [],
    "soft": []
  },
  "experience": [
    {
      "title": "",
      "company": "",
      "location": "",
      "start_date": "",
      "end_date": "",
      "responsibilities": []
    }
  ],
  "projects": [
    {
      "name": "",
      "description": "",
      "technologies": [],
      "highlights": []
    }
  ],
  "certifications": []
}"""
    
    @staticmethod
    def build_mode1_prompt(
        full_name: str,
        job_description: str,
        experience_level: str,
        skills: Optional[List[str]] = None,
        education: Optional[str] = None
    ) -> str:
        """
        Build prompt for Mode 1: JD-based generation
        
        Args:
            full_name: Candidate's full name
            job_description: Target job description
            experience_level: Experience level (entry/mid/senior)
            skills: Optional list of skills
            education: Optional education information
            
        Returns:
            Formatted user prompt
        """
        prompt = f"""Generate an ATS-optimized resume for the following:

CANDIDATE INFORMATION:
- Full Name: {full_name}
- Experience Level: {experience_level}
"""
        
        if skills:
            prompt += f"- Skills: {', '.join(skills)}\n"
        
        if education:
            prompt += f"- Education: {education}\n"
        
        prompt += f"""
TARGET JOB DESCRIPTION:
{job_description}

INSTRUCTIONS:
1. Extract key requirements and keywords from the job description
2. Create a professional summary that aligns with the role
3. Organize technical skills to match JD requirements
4. Generate relevant experience examples that demonstrate the required skills
5. Ensure the resume is tailored for this specific role
6. Use action verbs and quantify achievements where possible
7. Keep it to 2 pages maximum

Generate the resume in the specified JSON format."""
        
        return prompt
    
    @staticmethod
    def build_mode2_prompt(
        job_description: Optional[str] = None,
        resume_text: Optional[str] = None,
        github_data: Optional[Dict[str, Any]] = None,
        linkedin_data: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Build prompt for Mode 2: Profile analysis
        
        Args:
            job_description: Optional target job description
            resume_text: Parsed resume content
            github_data: GitHub profile data
            linkedin_data: LinkedIn profile data
            
        Returns:
            Formatted user prompt
        """
        prompt = "Generate an ATS-optimized resume based on the following profile information:\n\n"
        
        if resume_text:
            prompt += f"""EXISTING RESUME:
{resume_text}

"""
        
        if github_data:
            prompt += f"""GITHUB PROFILE:
- Username: {github_data.get('username', 'N/A')}
- Top Repositories: {', '.join(github_data.get('top_repos', [])[:5])}
- Primary Languages: {', '.join(github_data.get('languages', []))}
- Total Repositories: {github_data.get('repo_count', 0)}

"""
        
        if linkedin_data:
            prompt += f"""LINKEDIN PROFILE:
- Experience: {linkedin_data.get('experience_summary', 'N/A')}
- Skills: {', '.join(linkedin_data.get('skills', []))}

"""
        
        if job_description:
            prompt += f"""TARGET JOB DESCRIPTION:
{job_description}

"""
        
        prompt += """INSTRUCTIONS:
1. Analyze all provided information to create a comprehensive profile
2. Extract relevant experience, projects, and skills
3. If a job description is provided, tailor the resume to match its requirements
4. Organize information in ATS-friendly format
5. Highlight achievements and quantify results where possible
6. Ensure consistency across all sections
7. Keep it to 2 pages maximum

Generate the resume in the specified JSON format."""
        
        return prompt
    
    @staticmethod
    def get_system_prompt() -> str:
        """Get the system prompt"""
        return PromptBuilder.SYSTEM_PROMPT
