# AI-Powered ATS Resume Builder

A local AI-powered web application that generates ATS-optimized resumes using Ollama LLM. The system supports two generation modes: JD-based creation and smart profile analysis from resumes, GitHub, and LinkedIn.

## Features

- **Local AI Processing**: Uses Ollama for complete privacy - no data leaves your machine
- **Two Generation Modes**:
  - **Mode 1**: Generate resume from job description and basic info
  - **Mode 2**: Import and optimize from existing resume, GitHub, or LinkedIn
- **ATS-Optimized**: Strict 2-page format with proper structure and formatting
- **Privacy Mode**: Blur header information in preview
- **PDF Export**: Clean, machine-readable PDF output
- **Smart Analysis**: 
  - Job description keyword extraction
  - GitHub repository analysis
  - Experience and skills optimization

## Prerequisites

### 1. Install Ollama

Download and install Ollama from [https://ollama.ai](https://ollama.ai)

After installation, pull the recommended model:

```bash
ollama pull llama3:instruct
```

Alternative models:
```bash
ollama pull llama3
ollama pull mistral
```

### 2. Python Requirements

- Python 3.8 or higher
- pip package manager

## Installation

### 1. Clone or Download the Project

```bash
cd d:\TheDeuce\resume_builder
```

### 2. Create Virtual Environment

```bash
python -m venv venv
```

### 3. Activate Virtual Environment

**Windows:**
```bash
venv\Scripts\activate
```

**macOS/Linux:**
```bash
source venv/bin/activate
```

### 4. Install Dependencies

```bash
pip install -r requirements.txt
```

## Configuration

### Environment Variables (Optional)

Create a `.env` file in the project root:

```env
# Ollama Configuration
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=llama3:instruct

# GitHub API (optional, for higher rate limits)
GITHUB_TOKEN=your_github_token_here

# Flask Configuration
FLASK_DEBUG=True
SECRET_KEY=your-secret-key-here
```

## Usage

### 1. Start Ollama

Ensure Ollama is running:

```bash
ollama serve
```

### 2. Run the Application

```bash
python app.py
```

The application will start at `http://localhost:5000`

### 3. Generate a Resume

#### Mode 1: JD-Based Generation

1. Select "JD-Based Generation"
2. Enter your full name
3. Select experience level
4. Paste the job description
5. Optionally add skills and education
6. Click "Generate Resume"

#### Mode 2: Profile Analysis

1. Select "Smart Profile Analysis"
2. Upload your existing resume (PDF/DOCX), OR
3. Enter your GitHub profile URL, OR
4. Enter your LinkedIn profile URL
5. Optionally paste target job description
6. Click "Generate Resume"

### 4. Preview and Download

- View your generated resume
- Toggle blur on/off for privacy
- Download as PDF
- Create another resume if needed

## Project Structure

```
resume_builder/
│
├── app.py                      # Main Flask application
├── config.py                   # Configuration settings
├── requirements.txt            # Python dependencies
│
├── ai_engine/                  # AI processing modules
│   ├── ollama_client.py       # Ollama LLM interface
│   ├── prompt_builder.py      # Prompt construction
│   ├── jd_analyzer.py         # Job description analysis
│   ├── github_scraper.py      # GitHub profile scraper
│   └── linkedin_parser.py     # LinkedIn data handler
│
├── resume_parser/             # Resume parsing modules
│   ├── pdf_parser.py          # PDF resume parser
│   └── docx_parser.py         # DOCX resume parser
│
├── templates/                 # HTML templates
│   ├── form.html             # Main input form
│   ├── preview.html          # Resume preview
│   └── error.html            # Error page
│
├── utils/                     # Utility modules
│   └── pdf_generator.py      # PDF generation
│
├── uploads/                   # Temporary file uploads
└── output/                    # Generated PDFs
```

## API Endpoints

- `GET /` - Main form page
- `POST /generate` - Generate resume (returns preview)
- `GET /download/<filename>` - Download PDF resume
- `GET /health` - Health check and Ollama status

## Troubleshooting

### Ollama Connection Issues

**Error**: "Cannot connect to Ollama"

**Solution**:
1. Ensure Ollama is installed: `ollama --version`
2. Start Ollama service: `ollama serve`
3. Check if running: `curl http://localhost:11434`
4. Pull required model: `ollama pull llama3:instruct`

### PDF Generation Issues

**Error**: "Failed to generate PDF"

**Solution**:
- Ensure WeasyPrint dependencies are installed
- On Windows, you may need to install GTK3 runtime
- Check output folder permissions

### File Upload Issues

**Error**: "File upload failed"

**Solution**:
- Check file size (max 16MB)
- Ensure file format is PDF or DOCX
- Verify uploads folder exists and is writable

### GitHub Rate Limiting

**Issue**: GitHub API rate limit exceeded

**Solution**:
- Create a GitHub personal access token
- Add to `.env` file: `GITHUB_TOKEN=your_token`
- Restart the application

## Privacy & Data

- **All processing is local**: No data is sent to external servers
- **Ollama runs locally**: Your resume data never leaves your machine
- **Temporary files**: Uploaded files are stored temporarily in `uploads/`
- **Generated PDFs**: Saved in `output/` folder
- **Manual cleanup**: Delete files from `uploads/` and `output/` as needed

## ATS Compliance

The generated resumes follow strict ATS (Applicant Tracking System) guidelines:

- ✅ Times New Roman font
- ✅ Standard 11-12pt font size
- ✅ Clean, simple formatting
- ✅ No graphics, tables, or columns
- ✅ Proper section hierarchy
- ✅ Machine-readable text
- ✅ Standard 2-page format
- ✅ Appropriate margins and spacing

## Technical Stack

- **Backend**: Flask (Python)
- **AI Engine**: Ollama (llama3:instruct)
- **PDF Generation**: WeasyPrint
- **Resume Parsing**: PyPDF2, python-docx
- **Web Scraping**: Requests, BeautifulSoup4
- **Frontend**: HTML, CSS, JavaScript

## License

This project is open source and available for personal and commercial use.

## Support

For issues, questions, or contributions:
1. Check the troubleshooting section
2. Review Ollama documentation: https://ollama.ai/docs
3. Check Flask documentation: https://flask.palletsprojects.com/

## Future Enhancements

- ATS score calculation
- Multiple resume templates
- LinkedIn direct integration (with API)
- Batch resume generation
- Resume version comparison
- Custom styling options
- Export to multiple formats

---

**Built with ❤️ using Ollama and Flask**
