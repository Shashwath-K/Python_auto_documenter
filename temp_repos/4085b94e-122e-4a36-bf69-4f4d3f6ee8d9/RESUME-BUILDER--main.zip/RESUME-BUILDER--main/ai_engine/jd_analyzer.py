"""
Job Description Analyzer
Extracts keywords, skills, and requirements from job descriptions
"""
import re
from typing import Dict, List, Set
from collections import Counter


class JDAnalyzer:
    """Analyzes job descriptions to extract key information"""
    
    # Common technical skills and tools
    TECH_KEYWORDS = {
        'python', 'java', 'javascript', 'typescript', 'c++', 'c#', 'go', 'rust', 'ruby',
        'react', 'angular', 'vue', 'node.js', 'express', 'django', 'flask', 'spring',
        'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'jenkins', 'git', 'ci/cd',
        'sql', 'nosql', 'mongodb', 'postgresql', 'mysql', 'redis',
        'machine learning', 'deep learning', 'ai', 'nlp', 'computer vision',
        'agile', 'scrum', 'devops', 'microservices', 'api', 'rest', 'graphql',
        'security', 'testing', 'automation', 'cloud', 'data', 'analytics'
    }
    
    SKILL_INDICATORS = [
        r'skills?:',
        r'requirements?:',
        r'qualifications?:',
        r'experience with',
        r'proficiency in',
        r'knowledge of',
        r'familiar with'
    ]
    
    @staticmethod
    def analyze(job_description: str) -> Dict[str, any]:
        """
        Analyze job description and extract key information
        
        Args:
            job_description: The job description text
            
        Returns:
            Dictionary containing analyzed data
        """
        jd_lower = job_description.lower()
        
        # Extract keywords
        keywords = JDAnalyzer._extract_keywords(jd_lower)
        
        # Extract technical skills
        technical_skills = JDAnalyzer._extract_technical_skills(jd_lower)
        
        # Identify required vs preferred
        required_skills, preferred_skills = JDAnalyzer._categorize_skills(job_description)
        
        # Extract responsibilities
        responsibilities = JDAnalyzer._extract_responsibilities(job_description)
        
        # Detect role/title
        role = JDAnalyzer._extract_role(job_description)
        
        return {
            'role': role,
            'keywords': keywords,
            'technical_skills': list(technical_skills),
            'required_skills': list(required_skills),
            'preferred_skills': list(preferred_skills),
            'responsibilities': responsibilities
        }
    
    @staticmethod
    def _extract_keywords(text: str) -> List[str]:
        """Extract and rank keywords by frequency"""
        # Remove common words
        common_words = {'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'a', 'an'}
        
        # Extract words
        words = re.findall(r'\b[a-z]+\b', text)
        
        # Filter and count
        filtered_words = [w for w in words if w not in common_words and len(w) > 3]
        word_counts = Counter(filtered_words)
        
        # Return top keywords
        return [word for word, count in word_counts.most_common(20)]
    
    @staticmethod
    def _extract_technical_skills(text: str) -> Set[str]:
        """Extract technical skills from job description"""
        found_skills = set()
        
        for skill in JDAnalyzer.TECH_KEYWORDS:
            if skill in text:
                found_skills.add(skill)
        
        return found_skills
    
    @staticmethod
    def _categorize_skills(text: str) -> tuple:
        """Categorize skills into required vs preferred"""
        required = set()
        preferred = set()
        
        lines = text.split('\n')
        in_required_section = False
        in_preferred_section = False
        
        for line in lines:
            line_lower = line.lower()
            
            # Check section headers
            if any(word in line_lower for word in ['required', 'must have', 'minimum']):
                in_required_section = True
                in_preferred_section = False
            elif any(word in line_lower for word in ['preferred', 'nice to have', 'bonus']):
                in_required_section = False
                in_preferred_section = True
            
            # Extract skills from current line
            for skill in JDAnalyzer.TECH_KEYWORDS:
                if skill in line_lower:
                    if in_required_section:
                        required.add(skill)
                    elif in_preferred_section:
                        preferred.add(skill)
        
        return required, preferred
    
    @staticmethod
    def _extract_responsibilities(text: str) -> List[str]:
        """Extract job responsibilities"""
        responsibilities = []
        
        # Find bullet points or numbered items
        lines = text.split('\n')
        
        for line in lines:
            line = line.strip()
            # Check if line starts with bullet or number
            if re.match(r'^[\-\*•\d]+\.?\s+', line):
                # Clean the line
                cleaned = re.sub(r'^[\-\*•\d]+\.?\s+', '', line)
                if len(cleaned) > 20:  # Meaningful responsibility
                    responsibilities.append(cleaned)
        
        return responsibilities[:10]  # Top 10 responsibilities
    
    @staticmethod
    def _extract_role(text: str) -> str:
        """Extract job role/title from job description"""
        lines = text.split('\n')
        
        # Common role indicators
        role_patterns = [
            r'(?:position|role|title):\s*(.+)',
            r'^(.+(?:engineer|developer|analyst|manager|scientist|architect|designer))',
            r'(?:seeking|hiring|looking for)\s+(?:a|an)?\s*(.+?)(?:\s+to|\s+who|\s+with)',
        ]
        
        for line in lines[:10]:  # Check first 10 lines
            for pattern in role_patterns:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    role = match.group(1).strip()
                    # Clean up
                    role = re.sub(r'\s+', ' ', role)
                    if len(role) < 50:  # Reasonable length
                        return role
        
        return "Professional"  # Default
