# AI Resume Builder - Setup Guide

## Quick Start

Follow these steps to set up and run the AI-powered Resume Builder:

### Step 1: Install Ollama

1. Download Ollama from https://ollama.ai
2. Install the application
3. Open a terminal and pull the model:
   ```
   ollama pull llama3:instruct
   ```

### Step 2: Set Up Python Environment

1. Open PowerShell or Command Prompt
2. Navigate to the project directory:
   ```
   cd d:\TheDeuce\resume_builder
   ```
3. Create a virtual environment:
   ```
   python -m venv venv
   ```
4. Activate the virtual environment:
   ```
   venv\Scripts\activate
   ```
5. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

### Step 3: Start Ollama Server

In a separate terminal:
```
ollama serve
```

### Step 4: Run the Application

In your project terminal (with venv activated):
```
python app.py
```

### Step 5: Access the Application

Open your browser and go to:
```
http://localhost:5000
```

## First Time Use

1. Choose your mode:
   - **Mode 1**: Create from job description
   - **Mode 2**: Import from existing resume/GitHub

2. Fill in the required information

3. Click "Generate Resume"

4. Wait 30-60 seconds for AI processing

5. Preview, adjust blur, and download your resume!

## Troubleshooting

**Can't connect to Ollama?**
- Make sure `ollama serve` is running
- Check http://localhost:11434 in your browser

**Import errors?**
- Ensure virtual environment is activated
- Run `pip install -r requirements.txt` again

**Slow generation?**
- First run downloads the model (may take time)
- Subsequent runs are faster
- Consider using a smaller model if needed

## Need Help?

Check the full README.md for detailed documentation.
