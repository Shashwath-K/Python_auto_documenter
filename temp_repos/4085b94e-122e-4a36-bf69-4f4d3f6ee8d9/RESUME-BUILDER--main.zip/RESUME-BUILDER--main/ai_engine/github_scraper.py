"""
GitHub Profile Scraper
Extracts repository and profile information from GitHub
"""
import requests
import logging
from typing import Dict, List, Optional
from collections import Counter

logger = logging.getLogger(__name__)


class GitHubScraper:
    """Scrapes GitHub profiles for resume data"""
    
    def __init__(self, api_token: Optional[str] = None):
        """
        Initialize GitHub scraper
        
        Args:
            api_token: Optional GitHub API token for higher rate limits
        """
        self.base_url = 'https://api.github.com'
        self.headers = {}
        if api_token:
            self.headers['Authorization'] = f'token {api_token}'
    
    def analyze_profile(self, username: str) -> Optional[Dict]:
        """
        Analyze a GitHub profile
        
        Args:
            username: GitHub username
            
        Returns:
            Dictionary containing profile analysis
        """
        try:
            logger.info(f"Analyzing GitHub profile: {username}")
            
            # Get user info
            user_data = self._get_user_data(username)
            if not user_data:
                return None
            
            # Get repositories
            repos = self._get_repositories(username)
            
            # Analyze repositories
            analysis = self._analyze_repositories(repos)
            
            return {
                'username': username,
                'name': user_data.get('name', username),
                'bio': user_data.get('bio', ''),
                'location': user_data.get('location', ''),
                'email': user_data.get('email', ''),
                'blog': user_data.get('blog', ''),
                'repo_count': user_data.get('public_repos', 0),
                'top_repos': analysis['top_repos'],
                'languages': analysis['languages'],
                'topics': analysis['topics'],
                'total_stars': analysis['total_stars']
            }
            
        except Exception as e:
            logger.error(f"Error analyzing GitHub profile: {str(e)}")
            return None
    
    def _get_user_data(self, username: str) -> Optional[Dict]:
        """Get user profile data from GitHub API"""
        try:
            url = f"{self.base_url}/users/{username}"
            response = requests.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"GitHub API error: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"Error fetching user data: {str(e)}")
            return None
    
    def _get_repositories(self, username: str, max_repos: int = 100) -> List[Dict]:
        """Get user's repositories"""
        try:
            url = f"{self.base_url}/users/{username}/repos"
            params = {
                'sort': 'updated',
                'per_page': min(max_repos, 100)
            }
            response = requests.get(url, headers=self.headers, params=params, timeout=10)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Error fetching repositories: {response.status_code}")
                return []
                
        except Exception as e:
            logger.error(f"Error fetching repositories: {str(e)}")
            return []
    
    def _analyze_repositories(self, repos: List[Dict]) -> Dict:
        """Analyze repositories to extract insights"""
        if not repos:
            return {
                'top_repos': [],
                'languages': [],
                'topics': [],
                'total_stars': 0
            }
        
        # Sort by stars
        sorted_repos = sorted(repos, key=lambda x: x.get('stargazers_count', 0), reverse=True)
        
        # Get top repositories
        top_repos = []
        for repo in sorted_repos[:5]:
            top_repos.append({
                'name': repo['name'],
                'description': repo.get('description', ''),
                'language': repo.get('language', ''),
                'stars': repo.get('stargazers_count', 0),
                'url': repo['html_url']
            })
        
        # Extract languages
        language_counter = Counter()
        for repo in repos:
            lang = repo.get('language')
            if lang:
                language_counter[lang] += 1
        
        # Extract topics
        topic_counter = Counter()
        for repo in repos:
            topics = repo.get('topics', [])
            for topic in topics:
                topic_counter[topic] += 1
        
        # Calculate total stars
        total_stars = sum(repo.get('stargazers_count', 0) for repo in repos)
        
        return {
            'top_repos': [r['name'] for r in top_repos],
            'languages': [lang for lang, _ in language_counter.most_common(10)],
            'topics': [topic for topic, _ in topic_counter.most_common(10)],
            'total_stars': total_stars
        }
    
    @staticmethod
    def extract_username(url: str) -> Optional[str]:
        """
        Extract username from GitHub URL
        
        Args:
            url: GitHub profile or repo URL
            
        Returns:
            Username or None
        """
        import re
        
        # Pattern to match GitHub URLs
        patterns = [
            r'github\.com/([^/]+)',
            r'^([a-zA-Z0-9](?:[a-zA-Z0-9]|-(?=[a-zA-Z0-9])){0,38})$'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
        
        return None
